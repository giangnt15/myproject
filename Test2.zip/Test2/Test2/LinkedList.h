#pragma once
#include "pch.h"
#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node {
	char data[4096];
	struct node *pNext;
}; typedef struct node NODE;
struct list {
	NODE *pHead;
	NODE *pTail;
}; typedef struct list LIST;
void init(LIST &l)
{
	l.pHead = NULL;
	l.pTail = NULL;
};
NODE *GetNode(char x[])
{
	NODE *p = (NODE*)malloc(sizeof(NODE));
	if (p == NULL) return NULL;
	strcpy(p->data, x);
	p->pNext = NULL;
	return p;
};
void AddHead(LIST &l, char data[]) {
	NODE *p = GetNode(data);
	if (l.pHead == NULL)
		l.pHead = l.pTail = p;
	else {
		p->pNext = l.pHead;
		l.pHead = p;
	}
};
void AddTail(LIST &l, char data[]) {
	NODE *p = GetNode(data);
	if (l.pHead == NULL)
		l.pHead = l.pTail = p;
	else {
		l.pTail->pNext = p;
		l.pTail = p;
		p->pNext = NULL;
	}
};

int listLength(LIST l)
{
	int i = 0;
	NODE *p = l.pHead;
	while (p!= NULL)
	{
		i++;
		p=p->pNext;
	} return i;
}
char *Mid(LIST l)
{
	NODE *p = l.pHead, *g = p;
	while (g->pNext->pNext != NULL)
	{
		p = p->pNext;
		g = g->pNext->pNext;
		if (g->pNext == NULL) return p->data;
		if (g->pNext == l.pTail) { return p->pNext->data; }
	}

}
void delHead(LIST &l)
{
	NODE *p = l.pHead;
	l.pHead = l.pHead->pNext;
	delete p; return;
}
void printList(LIST l)
{
	NODE *p = l.pHead;
	while (p != NULL)
	{
		puts(p->data);
		p = p->pNext;
	}
}
void delK(LIST &l, int k)
{
	NODE *p = l.pHead, *g; int i = 1;
	while (p->pNext != NULL && i != k - 1)
	{
		p = p->pNext;
		i++;
	}
	p->pNext = p->pNext->pNext;
}
void deleteList(LIST &l) {
	while (listLength(l) > 0) {
		delHead(l);
	}
}
NODE *getElementAt(LIST l,int index) {
	NODE *p = l.pHead;
	while (p != NULL&&index>=0) {
		if (index == 0) return p;
		index--;
		p = p->pNext;
	}
	return NULL;
}